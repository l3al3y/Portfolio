// IrfanLLM Mobile Manga Controller - Touchless Front Camera Reader
(function() {
    if (window.__IRFANLLM_ACTIVE__) {
        if (typeof window.__IRFANLLM_STOP__ === "function") {
            window.__IRFANLLM_STOP__();
        }
        return;
    }
    window.__IRFANLLM_ACTIVE__ = true;

    const POSTURE_MODEL = {"classes": [1, 2], "n_estimators": 100, "trees": [[[6, 0.2117048278450966, 1, 2, [0.7002801120448179, 0.29971988795518206]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[12, 0.32540126889944077, 1, 2, [0.7366946778711485, 0.26330532212885155]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[57, -0.1231829971075058, 1, 2, [0.7058823529411765, 0.29411764705882354]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[9, 0.3154120668768883, 1, 2, [0.6694677871148459, 0.33053221288515405]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[60, -0.11060245335102081, 1, 2, [0.7030812324929971, 0.2969187675070028]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[51, -0.14192544773686677, 1, 2, [0.7058823529411765, 0.29411764705882354]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[9, 0.27739713340997696, 1, 2, [0.7282913165266106, 0.27170868347338933]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[42, -0.02841392159461975, 1, 2, [0.7170868347338936, 0.28291316526610644]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[69, 0.2394532710313797, 1, 2, [0.7338935574229691, 0.2661064425770308]], [-2, -2.0, -1, -1, [1.0, 0.0]], [-2, -2.0, -1, -1, [0.0, 1.0]]], [[24, 0.16385890543460846, 1, 2, [0.711484593837535, 0.28851540616246496]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[33, 0.06379610300064087, 1, 2, [0.7254901960784313, 0.27450980392156865]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[63, -1.594558596611023, 1, 2, [0.6862745098039216, 0.3137254901960784]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[42, -0.033954352140426636, 1, 2, [0.6946778711484594, 0.30532212885154064]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[6, 0.21403124183416367, 1, 2, [0.711484593837535, 0.28851540616246496]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[57, -0.1231829971075058, 1, 2, [0.7507002801120448, 0.24929971988795518]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[21, 0.17811377346515656, 1, 2, [0.7086834733893558, 0.2913165266106443]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[63, -1.594558596611023, 1, 2, [0.7338935574229691, 0.2661064425770308]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[19, -1.3285654783248901, 1, 2, [0.6918767507002801, 0.3081232492997199]], [-2, -2.0, -1, -1, [0.0, 1.0]], [36, -0.043511003255844116, 3, 4, [0.8458904109589042, 0.1541095890410959]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[33, 0.06379610300064087, 1, 2, [0.711484593837535, 0.28851540616246496]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[3, 0.12266664579510689, 1, 4, [0.7086834733893558, 0.2913165266106443]], [39, 0.16180984675884247, 2, 3, [0.15, 0.85]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]], [24, 0.17788336426019669, 5, 6, [0.9915611814345991, 0.008438818565400843]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[27, -0.016821548342704773, 1, 2, [0.7142857142857143, 0.2857142857142857]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[42, -0.02841392159461975, 1, 2, [0.7002801120448179, 0.29971988795518206]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[30, 0.051978349685668945, 1, 2, [0.6694677871148459, 0.33053221288515405]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[45, -0.03335833549499512, 1, 2, [0.7198879551820728, 0.2801120448179272]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[51, -0.16934220725670457, 1, 2, [0.7254901960784313, 0.27450980392156865]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[33, 0.07156530022621155, 1, 2, [0.6946778711484594, 0.30532212885154064]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[69, 0.23948025703430176, 1, 2, [0.6946778711484594, 0.30532212885154064]], [-2, -2.0, -1, -1, [1.0, 0.0]], [-2, -2.0, -1, -1, [0.0, 1.0]]], [[63, -1.594558596611023, 1, 2, [0.6862745098039216, 0.3137254901960784]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[69, 0.23791848123073578, 1, 2, [0.7254901960784313, 0.27450980392156865]], [-2, -2.0, -1, -1, [1.0, 0.0]], [-2, -2.0, -1, -1, [0.0, 1.0]]], [[30, 0.051978349685668945, 1, 2, [0.7198879551820728, 0.2801120448179272]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[9, 0.28122904151678085, 1, 2, [0.6666666666666666, 0.3333333333333333]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[54, -0.09222453832626343, 1, 2, [0.711484593837535, 0.28851540616246496]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[63, -1.594558596611023, 1, 2, [0.7030812324929971, 0.2969187675070028]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[27, -0.011853605508804321, 1, 2, [0.6862745098039216, 0.3137254901960784]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[9, 0.27739713340997696, 1, 2, [0.7058823529411765, 0.29411764705882354]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[30, 0.051978349685668945, 1, 2, [0.7310924369747899, 0.2689075630252101]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[33, 0.06379610300064087, 1, 2, [0.7366946778711485, 0.26330532212885155]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[9, 0.27739713340997696, 1, 2, [0.6862745098039216, 0.3137254901960784]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[63, -1.594558596611023, 1, 2, [0.7675070028011205, 0.23249299719887956]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[57, -0.1231829971075058, 1, 2, [0.7394957983193278, 0.2605042016806723]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[51, -0.1367844515480101, 1, 2, [0.7366946778711485, 0.26330532212885155]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[21, 0.17704735696315765, 1, 2, [0.7142857142857143, 0.2857142857142857]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[54, -0.09222453832626343, 1, 2, [0.7030812324929971, 0.2969187675070028]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[42, -0.02841392159461975, 1, 2, [0.6974789915966386, 0.3025210084033613]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[12, 0.29806550592184067, 1, 2, [0.7282913165266106, 0.27170868347338933]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[42, -0.04470545053482056, 1, 2, [0.6974789915966386, 0.3025210084033613]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[45, -0.03203010559082031, 1, 2, [0.7198879551820728, 0.2801120448179272]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[60, -0.10236608982086182, 1, 2, [0.7058823529411765, 0.29411764705882354]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[57, -0.1296275109052658, 1, 2, [0.6946778711484594, 0.30532212885154064]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[15, 0.1328301578760147, 1, 2, [0.7254901960784313, 0.27450980392156865]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[55, -0.4361068606376648, 1, 4, [0.6946778711484594, 0.30532212885154064]], [39, -0.06818988919258118, 2, 3, [0.10588235294117647, 0.8941176470588236]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]], [12, 0.2774081900715828, 5, 6, [0.8786764705882353, 0.1213235294117647]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[24, 0.16321305930614471, 1, 2, [0.680672268907563, 0.31932773109243695]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[63, -1.6019262671470642, 1, 2, [0.6946778711484594, 0.30532212885154064]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[12, 0.3175578936934471, 1, 2, [0.680672268907563, 0.31932773109243695]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[12, 0.32540126889944077, 1, 2, [0.7282913165266106, 0.27170868347338933]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[54, -0.06504480540752411, 1, 2, [0.7591036414565826, 0.24089635854341737]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[51, -0.10540267080068588, 1, 2, [0.7310924369747899, 0.2689075630252101]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[33, 0.06379610300064087, 1, 2, [0.7002801120448179, 0.29971988795518206]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[51, -0.14192544773686677, 1, 2, [0.711484593837535, 0.28851540616246496]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[6, 0.21270280331373215, 1, 2, [0.7086834733893558, 0.2913165266106443]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[51, -0.10540267080068588, 1, 2, [0.7198879551820728, 0.2801120448179272]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[6, 0.21270280331373215, 1, 2, [0.7394957983193278, 0.2605042016806723]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[18, 0.12842360138893127, 1, 2, [0.711484593837535, 0.28851540616246496]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[33, 0.05102206766605377, 1, 2, [0.711484593837535, 0.28851540616246496]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[21, 0.17704735696315765, 1, 2, [0.7591036414565826, 0.24089635854341737]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[27, -0.026275619864463806, 1, 2, [0.7198879551820728, 0.2801120448179272]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[45, -0.0434035062789917, 1, 2, [0.7198879551820728, 0.2801120448179272]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[51, -0.1367844515480101, 1, 2, [0.7254901960784313, 0.27450980392156865]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[18, 0.153352752327919, 1, 2, [0.680672268907563, 0.31932773109243695]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[18, 0.14957471191883087, 1, 2, [0.7030812324929971, 0.2969187675070028]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[12, 0.3261997401714325, 1, 2, [0.6946778711484594, 0.30532212885154064]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[42, -0.0519031286239624, 1, 2, [0.7086834733893558, 0.2913165266106443]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[69, 0.23764047026634216, 1, 2, [0.7198879551820728, 0.2801120448179272]], [-2, -2.0, -1, -1, [1.0, 0.0]], [-2, -2.0, -1, -1, [0.0, 1.0]]], [[58, -0.44819962978363037, 1, 4, [0.7394957983193278, 0.2605042016806723]], [59, -0.34223319590091705, 2, 3, [0.04838709677419355, 0.9516129032258065]], [-2, -2.0, -1, -1, [1.0, 0.0]], [-2, -2.0, -1, -1, [0.0, 1.0]], [63, -1.6205082535743713, 5, 6, [0.8847457627118644, 0.1152542372881356]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[57, -0.1326783448457718, 1, 2, [0.7170868347338936, 0.28291316526610644]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[12, 0.31835636496543884, 1, 2, [0.7254901960784313, 0.27450980392156865]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[9, 0.28040458261966705, 1, 2, [0.7338935574229691, 0.2661064425770308]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[18, 0.14957471191883087, 1, 2, [0.711484593837535, 0.28851540616246496]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[48, -0.06241104006767273, 1, 2, [0.6694677871148459, 0.33053221288515405]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[39, -0.12884938716888428, 1, 2, [0.7366946778711485, 0.26330532212885155]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[54, -0.11535938084125519, 1, 2, [0.711484593837535, 0.28851540616246496]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[57, -0.11423543095588684, 1, 2, [0.6890756302521008, 0.31092436974789917]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[54, -0.1425391137599945, 1, 2, [0.7198879551820728, 0.2801120448179272]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[15, 0.1015625, 1, 2, [0.742296918767507, 0.25770308123249297]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[15, 0.13484176993370056, 1, 2, [0.7282913165266106, 0.27170868347338933]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[57, -0.11423543095588684, 1, 2, [0.7254901960784313, 0.27450980392156865]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[48, -0.05067569017410278, 1, 2, [0.711484593837535, 0.28851540616246496]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[15, 0.11319451779127121, 1, 2, [0.7563025210084033, 0.24369747899159663]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[54, -0.09222453832626343, 1, 2, [0.6918767507002801, 0.3081232492997199]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[12, 0.3032892346382141, 1, 2, [0.711484593837535, 0.28851540616246496]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[12, 0.3032892346382141, 1, 2, [0.7226890756302521, 0.2773109243697479]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[30, 0.06341207027435303, 1, 2, [0.7030812324929971, 0.2969187675070028]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[21, 0.17811377346515656, 1, 2, [0.7058823529411765, 0.29411764705882354]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[21, 0.17811377346515656, 1, 2, [0.7310924369747899, 0.2689075630252101]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[69, 0.2381765991449356, 1, 2, [0.7086834733893558, 0.2913165266106443]], [-2, -2.0, -1, -1, [1.0, 0.0]], [-2, -2.0, -1, -1, [0.0, 1.0]]], [[24, 0.17788336426019669, 1, 2, [0.7058823529411765, 0.29411764705882354]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[24, 0.17788336426019669, 1, 2, [0.7198879551820728, 0.2801120448179272]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[51, -0.14192544773686677, 1, 2, [0.7086834733893558, 0.2913165266106443]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[12, 0.31835636496543884, 1, 2, [0.7983193277310925, 0.20168067226890757]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]], [[18, 0.13813184201717377, 1, 2, [0.7198879551820728, 0.2801120448179272]], [-2, -2.0, -1, -1, [0.0, 1.0]], [-2, -2.0, -1, -1, [1.0, 0.0]]]]};
    const CONF_THRESHOLD = 0.80;
    const COOLDOWN_BUTTON = 700; // 0.7s
    const BASE_CRUISE_SPEED = 10.5; // continuous pixels per frame at 60fps (~630px/sec)
    const FLICK_BOOST = 22.0;       // kinetic swipe impulse (matches smartphone touchscreen flick)
    const FRICTION = 0.935;         // exponential momentum damping
    const ACCELERATION = 0.16;      // smooth ease-in when gesture starts

    let speedMultiplier = 1.0;
    let currentVelocity = 0.0;
    let targetVelocity = 0.0;
    let lastPhysicsTime = performance.now();
    let physicsAnimId = null;

    let lastWristY = null;
    let lastWristTime = 0;

    let cooldownUntil = 0;
    let btnPrevHoverStart = null;
    let btnNextHoverStart = null;
    let activeStream = null;
    let isProcessing = false;
    let animFrameId = null;
    let handsInstance = null;

    // 1. Stop / Cleanup Function
    function stopController() {
        if (activeStream) {
            activeStream.getTracks().forEach(t => {
                try { t.stop(); } catch (e) {}
            });
            activeStream = null;
        }
        if (animFrameId) {
            cancelAnimationFrame(animFrameId);
            animFrameId = null;
        }
        if (physicsAnimId) {
            cancelAnimationFrame(physicsAnimId);
            physicsAnimId = null;
        }
        currentVelocity = 0;
        targetVelocity = 0;
        lastWristY = null;
        lastWristTime = 0;
        if (video) {
            video.pause();
            video.srcObject = null;
        }
        if (handsInstance && typeof handsInstance.close === "function") {
            try { handsInstance.close(); } catch (e) {}
            handsInstance = null;
        }
        if (typeof stealthTimeout !== "undefined" && stealthTimeout) {
            clearTimeout(stealthTimeout);
            stealthTimeout = null;
        }
        const oldStyle = document.getElementById("irfanllm-dynamic-island-styles");
        if (oldStyle && oldStyle.parentNode) {
            oldStyle.parentNode.removeChild(oldStyle);
        }
        if (container && container.parentNode) {
            container.parentNode.removeChild(container);
        }
        if (donateModal && donateModal.parentNode) {
            donateModal.parentNode.removeChild(donateModal);
            donateModal = null;
        }
        window.__IRFANLLM_ACTIVE__ = false;
        window.__IRFANLLM_STOP__ = null;
        try {
            sessionStorage.removeItem("__IRFANLLM_ACTIVE__");
            sessionStorage.setItem("__IRFANLLM_ACTIVE__", "false");
        } catch (e) {}

        const demoArea = document.getElementById("webtoon-scroll-area");
        if (demoArea) {
            demoArea.style.borderColor = "";
            demoArea.style.boxShadow = "";
        }

        const pageBtn = document.getElementById("btn-camera");
        if (pageBtn) {
            pageBtn.innerText = "Activate Front Camera Demo";
            pageBtn.style.background = "";
            pageBtn.disabled = false;
        }
    }
    window.__IRFANLLM_STOP__ = stopController;

    // 2. Create Floating UI Overlay with Apple-Style Dynamic Island
    const container = document.createElement("div");
    container.id = "irfanllm-overlay";
    container.style.cssText = "position:fixed;top:0;left:0;width:100%;height:100%;pointer-events:none;z-index:999999;font-family:-apple-system,BlinkMacSystemFont,'SF Pro Text','Segoe UI',Roboto,sans-serif;";

    // Embedded Dynamic Island CSS Styles
    const styleEl = document.createElement("style");
    styleEl.id = "irfanllm-dynamic-island-styles";
    styleEl.textContent = `
        @keyframes irfanllm-pulse {
            0%, 100% { transform: scale(1); opacity: 1; }
            50% { transform: scale(0.75); opacity: 0.45; }
        }
        .irfanllm-island-root {
            position: fixed;
            top: 10px;
            left: 50%;
            transform: translateX(-50%);
            z-index: 1000000;
            pointer-events: auto;
            user-select: none;
            -webkit-user-select: none;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .irfanllm-pill {
            height: 36px;
            min-width: 140px;
            max-width: 290px;
            background: #000000;
            border: 1px solid rgba(255, 255, 255, 0.16);
            border-radius: 9999px;
            padding: 0 12px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 8px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.8), 0 0 0 1px rgba(0,0,0,0.9);
            backdrop-filter: blur(24px);
            -webkit-backdrop-filter: blur(24px);
            cursor: pointer;
            transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
            color: #f8fafc;
        }
        .irfanllm-pill:hover {
            border-color: rgba(255, 255, 255, 0.28);
            transform: scale(1.02);
        }
        .irfanllm-pill.stealth {
            min-width: 44px !important;
            width: 44px !important;
            height: 7px !important;
            padding: 0 !important;
            border-radius: 9999px !important;
            background: rgba(0,0,0,0.35) !important;
            border-color: rgba(255,255,255,0.06) !important;
            box-shadow: none !important;
            opacity: 0.35 !important;
        }
        .irfanllm-pill.stealth * {
            opacity: 0 !important;
            pointer-events: none !important;
        }
        .irfanllm-dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: #10b981;
            box-shadow: 0 0 8px #10b981;
            flex-shrink: 0;
            transition: background 0.25s, box-shadow 0.25s;
        }
        .irfanllm-dot.pulse {
            animation: irfanllm-pulse 1.8s infinite ease-in-out;
        }
        .irfanllm-card {
            width: 320px;
            max-width: calc(100vw - 24px);
            background: rgba(8, 12, 22, 0.96);
            border: 1px solid rgba(255, 255, 255, 0.16);
            border-radius: 24px;
            padding: 16px 18px;
            box-shadow: 0 25px 60px rgba(0,0,0,0.9), 0 0 35px rgba(56,189,248,0.2);
            backdrop-filter: blur(28px);
            -webkit-backdrop-filter: blur(28px);
            display: none;
            flex-direction: column;
            gap: 12px;
            margin-top: 8px;
            color: #f8fafc;
            animation: irfanllm-pop 0.3s cubic-bezier(0.16, 1, 0.3, 1);
        }
        @keyframes irfanllm-pop {
            from { opacity: 0; transform: scale(0.92) translateY(-10px); }
            to { opacity: 1; transform: scale(1) translateY(0); }
        }
        .irfanllm-edge-zone {
            position: fixed;
            top: 25%;
            bottom: 25%;
            width: 55px;
            pointer-events: auto;
            z-index: 999998;
            display: flex;
            align-items: center;
        }
        .irfanllm-edge-pill {
            padding: 14px 8px;
            border-radius: 14px;
            background: rgba(8, 12, 22, 0.88);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            border: 1px solid rgba(56, 189, 248, 0.3);
            color: #38bdf8;
            font-size: 11px;
            font-weight: 800;
            writing-mode: vertical-rl;
            text-orientation: mixed;
            box-shadow: 0 8px 24px rgba(0,0,0,0.6), 0 0 15px rgba(56,189,248,0.25);
            opacity: 0;
            cursor: pointer;
            transition: all 0.28s cubic-bezier(0.16, 1, 0.3, 1);
            user-select: none;
            -webkit-tap-highlight-color: transparent;
        }
        .irfanllm-edge-pill.hovered {
            opacity: 1 !important;
            transform: translateX(0) !important;
            border-color: #34d399 !important;
            color: #34d399 !important;
            box-shadow: 0 8px 24px rgba(0,0,0,0.7), 0 0 20px rgba(52,211,153,0.5) !important;
        }
    `;
    document.head.appendChild(styleEl);

    // Supporter / Tip Modal (Touch 'n Go DuitNow QR)
    let donateModal = null;
    function openDonationModal() {
        if (donateModal) {
            donateModal.style.display = "flex";
            return;
        }
        donateModal = document.createElement("div");
        donateModal.id = "irfanllm-donate-modal";
        donateModal.style.cssText = "position:fixed;top:0;left:0;width:100vw;height:100vh;background:rgba(0,0,0,0.82);backdrop-filter:blur(6px);z-index:1000000;display:flex;align-items:center;justify-content:center;padding:15px;pointer-events:auto;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;";
        
        donateModal.onclick = (e) => {
            if (e.target === donateModal) donateModal.style.display = "none";
        };

        const card = document.createElement("div");
        card.style.cssText = "background:#0f172a;border:1px solid rgba(244,63,94,0.4);border-radius:18px;max-width:320px;width:100%;padding:18px;box-shadow:0 20px 50px rgba(0,0,0,0.8),0 0 30px rgba(244,63,94,0.25);text-align:center;color:#fff;box-sizing:border-box;";
        
        card.innerHTML = `
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
                <div style="font-size:14px;font-weight:800;color:#fda4af;display:flex;align-items:center;gap:6px;">
                    <span>☕</span> <span>Support Developer</span>
                </div>
                <button type="button" id="irfanllm-donate-close" style="background:none;border:none;color:#94a3b8;font-size:22px;cursor:pointer;line-height:1;">&times;</button>
            </div>
            <div style="font-size:11px;color:#94a3b8;margin-bottom:10px;line-height:1.4;">
                100% Free &amp; Ad-Free! Scan with Touch 'n Go eWallet or DuitNow:
            </div>
            <div style="background:#fff;padding:8px;border-radius:12px;display:inline-block;box-shadow:0 8px 25px rgba(0,0,0,0.5);margin-bottom:10px;border:2px solid rgba(244,63,94,0.25);">
                <img src="https://irfanfahmi.com/assets/manga/tng_qr.png" alt="Touch 'n Go DuitNow QR" style="width:175px;height:auto;display:block;border-radius:8px;">
            </div>
            <div style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:8px;padding:6px;margin-bottom:10px;">
                <div style="font-size:11px;font-weight:800;color:#fff;">MUHAMMAD IRFAN FAHMI BIN SAMSUL KAMAR</div>
                <div style="font-size:10px;color:#34d399;margin-top:2px;">✓ Verified DuitNow Recipient</div>
            </div>
            <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:5px;margin-bottom:12px;">
                <div style="background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.08);border-radius:6px;padding:5px 2px;">
                    <div style="font-weight:800;color:#f59e0b;font-size:11px;">☕ RM 3</div>
                    <div style="font-size:9px;color:#94a3b8;">Teh Tarik</div>
                </div>
                <div style="background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.08);border-radius:6px;padding:5px 2px;">
                    <div style="font-weight:800;color:#38bdf8;font-size:11px;">🍜 RM 7</div>
                    <div style="font-size:9px;color:#94a3b8;">Mee Goreng</div>
                </div>
                <div style="background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.08);border-radius:6px;padding:5px 2px;">
                    <div style="font-weight:800;color:#c084fc;font-size:11px;">🚀 RM 15</div>
                    <div style="font-size:9px;color:#94a3b8;">AI Research</div>
                </div>
            </div>
            <a href="https://irfanfahmi.com/assets/manga/tng_qr.png" target="_blank" style="display:inline-block;color:#38bdf8;font-size:11px;text-decoration:none;font-weight:600;">
                🔍 Open Full-Size QR in New Tab
            </a>
        `;

        donateModal.appendChild(card);
        document.body.appendChild(donateModal);

        const closeBtn = card.querySelector("#irfanllm-donate-close");
        if (closeBtn) {
            closeBtn.onclick = () => donateModal.style.display = "none";
        }
    }

    // Dynamic Island Structure
    const islandRoot = document.createElement("div");
    islandRoot.className = "irfanllm-island-root";

    const islandPill = document.createElement("div");
    islandPill.id = "irfanllm-island-pill";
    islandPill.className = "irfanllm-pill";
    islandPill.title = "Tap to open IrfanLLM Controls";

    // Left: Indicator Dot & Status Text
    const leftBox = document.createElement("div");
    leftBox.style.cssText = "display:flex;align-items:center;gap:8px;overflow:hidden;white-space:nowrap;";

    const statusDot = document.createElement("div");
    statusDot.className = "irfanllm-dot pulse";

    const islandText = document.createElement("span");
    islandText.id = "irfanllm-status-text";
    islandText.style.cssText = "font-size:12px;font-weight:700;letter-spacing:-0.2px;color:#f8fafc;transition:color 0.2s;";
    islandText.innerText = "IrfanLLM: Starting Camera...";

    leftBox.appendChild(statusDot);
    leftBox.appendChild(islandText);

    // Right: Speed Badge
    const speedBadge = document.createElement("div");
    speedBadge.id = "irfanllm-speed-badge";
    speedBadge.style.cssText = "font-size:10px;font-weight:800;background:rgba(255,255,255,0.1);color:#38bdf8;padding:2px 7px;border-radius:9999px;border:1px solid rgba(56,189,248,0.3);flex-shrink:0;transition:all 0.2s;";
    speedBadge.innerText = "1.0x";

    islandPill.appendChild(leftBox);
    islandPill.appendChild(speedBadge);
    islandRoot.appendChild(islandPill);

    // Expanded Island Card (Control Sheet)
    const expandedCard = document.createElement("div");
    expandedCard.id = "irfanllm-expanded-card";
    expandedCard.className = "irfanllm-card";

    // Card Header
    const cardHeader = document.createElement("div");
    cardHeader.style.cssText = "display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid rgba(255,255,255,0.08);padding-bottom:8px;";
    cardHeader.innerHTML = `
        <div style="display:flex;align-items:center;gap:7px;">
            <span style="font-size:14px;">🏝️</span>
            <span style="font-size:13px;font-weight:800;color:#fff;letter-spacing:-0.3px;">IrfanLLM Dynamic Island</span>
            <span style="font-size:9px;font-weight:800;background:rgba(56,189,248,0.2);color:#38bdf8;padding:1px 5px;border-radius:4px;">v1.5.1</span>
        </div>
        <button type="button" id="irfanllm-card-collapse" style="background:rgba(255,255,255,0.08);border:none;color:#94a3b8;font-size:12px;cursor:pointer;padding:3px 8px;border-radius:9999px;font-weight:700;">▲</button>
    `;
    expandedCard.appendChild(cardHeader);

    // Reading Speed Segmented Pills
    const speedSection = document.createElement("div");
    speedSection.style.cssText = "display:flex;flex-direction:column;gap:5px;";
    speedSection.innerHTML = `<div style="font-size:10px;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:0.5px;">Reading Speed</div>`;
    
    const speedGroup = document.createElement("div");
    speedGroup.style.cssText = "display:grid;grid-template-columns:repeat(3,1fr);gap:6px;background:rgba(255,255,255,0.04);padding:3px;border-radius:12px;border:1px solid rgba(255,255,255,0.06);";
    
    const speeds = [
        { val: 0.7, label: "0.7x Gentle", color: "#a78bfa" },
        { val: 1.0, label: "1.0x Normal", color: "#38bdf8" },
        { val: 1.4, label: "1.4x Fast",   color: "#f59e0b" }
    ];

    const speedBtns = speeds.map(s => {
        const b = document.createElement("button");
        b.type = "button";
        b.style.cssText = `border:none;border-radius:9px;padding:6px 4px;font-size:11px;font-weight:700;cursor:pointer;transition:all 0.2s;background:${speedMultiplier === s.val ? "rgba(255,255,255,0.15)" : "transparent"};color:${speedMultiplier === s.val ? s.color : "#94a3b8"};`;
        b.innerText = s.label;
        b.onclick = (e) => {
            e.stopPropagation();
            speedMultiplier = s.val;
            speedBadge.innerText = s.val.toFixed(1) + "x";
            speedBadge.style.color = s.color;
            speedBadge.style.borderColor = s.color;
            speedBtns.forEach(other => {
                other.style.background = "transparent";
                other.style.color = "#94a3b8";
            });
            b.style.background = "rgba(255,255,255,0.15)";
            b.style.color = s.color;
        };
        speedGroup.appendChild(b);
        return b;
    });
    speedSection.appendChild(speedGroup);
    expandedCard.appendChild(speedSection);

    // Chapter Navigation Buttons
    const chapterSection = document.createElement("div");
    chapterSection.style.cssText = "display:grid;grid-template-columns:1fr 1fr;gap:8px;";
    
    const cardPrevBtn = document.createElement("button");
    cardPrevBtn.type = "button";
    cardPrevBtn.style.cssText = "background:rgba(56,189,248,0.1);border:1px solid rgba(56,189,248,0.25);border-radius:10px;padding:8px;color:#38bdf8;font-size:12px;font-weight:700;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:4px;transition:all 0.2s;";
    cardPrevBtn.innerHTML = "⏮ Prev Chapter";
    cardPrevBtn.onclick = (e) => { e.stopPropagation(); goToChapter('prev'); };
    
    const cardNextBtn = document.createElement("button");
    cardNextBtn.type = "button";
    cardNextBtn.style.cssText = "background:rgba(56,189,248,0.1);border:1px solid rgba(56,189,248,0.25);border-radius:10px;padding:8px;color:#38bdf8;font-size:12px;font-weight:700;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:4px;transition:all 0.2s;";
    cardNextBtn.innerHTML = "⏭ Next Chapter";
    cardNextBtn.onclick = (e) => { e.stopPropagation(); goToChapter('next'); };
    
    chapterSection.appendChild(cardPrevBtn);
    chapterSection.appendChild(cardNextBtn);
    expandedCard.appendChild(chapterSection);

    // Utilities Row: Camera Toggle, Donate, Stop
    const utilSection = document.createElement("div");
    utilSection.style.cssText = "display:grid;grid-template-columns:1fr 1fr 1fr;gap:6px;padding-top:4px;border-top:1px solid rgba(255,255,255,0.06);";
    
    // Cam toggle
    const cardCamBtn = document.createElement("button");
    cardCamBtn.type = "button";
    cardCamBtn.style.cssText = "background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:10px;padding:7px 4px;color:#cbd5e1;font-size:11px;font-weight:700;cursor:pointer;transition:all 0.2s;";
    cardCamBtn.innerText = "📷 Cam PiP";
    cardCamBtn.onclick = (e) => {
        e.stopPropagation();
        if (camBox.style.display === "none") {
            camBox.style.display = "block";
            cardCamBtn.style.color = "#34d399";
            cardCamBtn.style.borderColor = "#34d399";
        } else {
            camBox.style.display = "none";
            cardCamBtn.style.color = "#cbd5e1";
            cardCamBtn.style.borderColor = "rgba(255,255,255,0.1)";
        }
    };
    
    // Tip btn
    const cardTipBtn = document.createElement("button");
    cardTipBtn.type = "button";
    cardTipBtn.style.cssText = "background:rgba(244,63,94,0.15);border:1px solid rgba(244,63,94,0.3);border-radius:10px;padding:7px 4px;color:#fda4af;font-size:11px;font-weight:700;cursor:pointer;transition:all 0.2s;";
    cardTipBtn.innerText = "☕ Tip QR";
    cardTipBtn.onclick = (e) => {
        e.stopPropagation();
        openDonationModal();
    };

    // Stop btn
    const cardStopBtn = document.createElement("button");
    cardStopBtn.type = "button";
    cardStopBtn.style.cssText = "background:rgba(239,68,68,0.15);border:1px solid rgba(239,68,68,0.3);border-radius:10px;padding:7px 4px;color:#fca5a5;font-size:11px;font-weight:700;cursor:pointer;transition:all 0.2s;";
    cardStopBtn.innerText = "🔴 Stop";
    cardStopBtn.onclick = (e) => {
        e.stopPropagation();
        stopController();
    };

    utilSection.appendChild(cardCamBtn);
    utilSection.appendChild(cardTipBtn);
    utilSection.appendChild(cardStopBtn);
    expandedCard.appendChild(utilSection);

    islandRoot.appendChild(expandedCard);
    container.appendChild(islandRoot);

    // Expand / Collapse & Auto-Stealth Logic
    let isIslandExpanded = false;
    let stealthTimeout = null;

    function collapseIsland() {
        if (!isIslandExpanded) return;
        isIslandExpanded = false;
        expandedCard.style.display = "none";
        islandPill.style.display = "flex";
        resetStealthTimer();
    }

    function expandIsland() {
        if (isIslandExpanded) return;
        isIslandExpanded = true;
        clearTimeout(stealthTimeout);
        islandPill.classList.remove("stealth");
        expandedCard.style.display = "flex";
    }

    islandPill.onclick = (e) => {
        e.stopPropagation();
        if (islandPill.classList.contains("stealth")) {
            resetStealthTimer();
            return;
        }
        expandIsland();
    };

    const collapseBtn = expandedCard.querySelector("#irfanllm-card-collapse");
    if (collapseBtn) {
        collapseBtn.onclick = (e) => {
            e.stopPropagation();
            collapseIsland();
        };
    }

    function resetStealthTimer() {
        if (isIslandExpanded) return;
        islandPill.classList.remove("stealth");
        clearTimeout(stealthTimeout);
        stealthTimeout = setTimeout(() => {
            if (!isIslandExpanded && Math.abs(currentVelocity) < 0.2) {
                islandPill.classList.add("stealth");
            }
        }, 3500);
    }

    islandRoot.onmouseenter = () => resetStealthTimer();
    window.addEventListener("touchstart", (e) => {
        if (e.touches && e.touches[0] && e.touches[0].clientY < 60) {
            resetStealthTimer();
        }
    }, { passive: true });

    // Close expanded card if user taps outside
    document.addEventListener("click", (e) => {
        if (isIslandExpanded && !islandRoot.contains(e.target) && (!donateModal || !donateModal.contains(e.target))) {
            collapseIsland();
        }
    });

    // Backward-Compatible Proxies for seamless existing logic integration
    const bannerText = {
        _text: "IrfanLLM: Starting Camera...",
        set innerText(txt) {
            this._text = txt;
            islandText.innerText = txt;
            resetStealthTimer();
        },
        get innerText() {
            return this._text;
        }
    };

    const banner = {
        style: {
            set color(c) {
                statusDot.style.background = c;
                statusDot.style.boxShadow = `0 0 10px ${c}`;
                if (c === "#00ff66" || c === "#10b981") {
                    islandPill.style.borderColor = "rgba(16, 185, 129, 0.45)";
                } else if (c === "#38bdf8" || c === "#00ffea" || c === "#00e5ff") {
                    islandPill.style.borderColor = "rgba(56, 189, 248, 0.45)";
                } else if (c === "#ffea00" || c === "#fbbf24") {
                    islandPill.style.borderColor = "rgba(245, 158, 11, 0.45)";
                } else if (c === "#ffffff" || c === "#ff4444") {
                    islandPill.style.borderColor = "rgba(239, 68, 68, 0.6)";
                } else {
                    islandPill.style.borderColor = "rgba(255, 255, 255, 0.16)";
                }
            },
            set borderColor(c) {
                islandPill.style.borderColor = c;
            },
            set background(bg) {},
            set cursor(cur) {
                islandPill.style.cursor = cur;
            }
        },
        appendChild() {},
        set onclick(fn) {
            islandPill.onclick = fn;
        }
    };

    // Sleek Camera Preview PiP (Hidden by default for clean, unobstructed reading)
    const camBox = document.createElement("div");
    camBox.id = "irfanllm-cambox";
    camBox.style.cssText = "position:fixed;bottom:16px;right:16px;width:92px;height:120px;background:#000;border-radius:18px;overflow:hidden;border:1.5px solid rgba(56,189,248,0.35);box-shadow:0 12px 30px rgba(0,0,0,0.8);pointer-events:auto;display:none;z-index:999997;transition:all 0.3s cubic-bezier(0.16,1,0.3,1);";

    const video = document.createElement("video");
    video.style.cssText = "width:100%;height:100%;object-fit:cover;transform:scaleX(-1);";
    video.playsInline = true;
    video.muted = true;
    video.autoplay = true;
    video.setAttribute("playsinline", "");
    video.setAttribute("webkit-playsinline", "");
    video.setAttribute("muted", "");
    video.setAttribute("autoplay", "");
    camBox.appendChild(video);

    // Sleek Close button on Camera PiP
    const pipCloseBtn = document.createElement("button");
    pipCloseBtn.innerText = "✕";
    pipCloseBtn.title = "Hide Camera Preview";
    pipCloseBtn.style.cssText = "position:absolute;top:5px;right:5px;background:rgba(0,0,0,0.65);backdrop-filter:blur(6px);color:#fff;border:1px solid rgba(255,255,255,0.2);border-radius:50%;width:20px;height:20px;font-size:10px;cursor:pointer;display:flex;align-items:center;justify-content:center;z-index:2;";
    pipCloseBtn.onclick = (e) => {
        e.stopPropagation();
        camBox.style.display = "none";
        cardCamBtn.style.color = "#cbd5e1";
        cardCamBtn.style.borderColor = "rgba(255,255,255,0.1)";
    };
    camBox.appendChild(pipCloseBtn);
    container.appendChild(camBox);

    // Universal Manga Chapter Finder & Navigator
    function findChapterLink(direction) {
        // 1. Selector Search across known scanlation platforms
        const selectors = direction === 'prev' ? [
            "a[rel='prev']", ".nav-prev a", "a.nav-prev", ".prev-post", ".prev_page", "#prev-chapter",
            ".btn-prev", ".ch-prev", "a.prev", "button.prev", ".chapter-prev a", "a.btn-prev-chapter",
            ".chnav.prev a", "a[title*='Previous' i]", "a[title*='Prev' i]", ".select-pagination .prev",
            ".navi-change-chapter-btn-prev", "a.prev-chapter"
        ] : [
            "a[rel='next']", ".nav-next a", "a.nav-next", ".next-post", ".next_page", "#next-chapter",
            ".btn-next", ".ch-next", "a.next", "button.next", ".chapter-next a", "a.btn-next-chapter",
            ".chnav.next a", "a[title*='Next' i]", ".select-pagination .next",
            ".navi-change-chapter-btn-next", "a.next-chapter"
        ];

        for (const s of selectors) {
            const el = document.querySelector(s);
            if (el && (el.href || typeof el.click === "function")) return el;
        }

        // 2. Exact & Pattern Text Matching on all links/buttons (DemonicScans, Asura, MangaDex)
        const candidates = Array.from(document.querySelectorAll("a[href], button, [role='button']"));
        const prevPatterns = [
            /^\s*(<|«|←)?\s*(prev|previous)\s*(>|»|→)?\s*$/i,
            /^\s*(prev|previous)\s+chapter\s*$/i,
            /^\s*chapter\s+(prev|previous)\s*$/i,
            /^\s*(<|«|←)\s*prev\b/i
        ];
        const nextPatterns = [
            /^\s*(<|«|←)?\s*(next)\s*(>|»|→)?\s*$/i,
            /^\s*next\s+chapter\s*$/i,
            /^\s*chapter\s+next\s*$/i,
            /\bnext\s*(>|»|→)\s*$/i
        ];
        const patterns = direction === 'prev' ? prevPatterns : nextPatterns;

        for (const el of candidates) {
            const txt = (el.innerText || el.textContent || el.getAttribute("aria-label") || "").trim();
            for (const p of patterns) {
                if (p.test(txt)) {
                    return el;
                }
            }
        }

        // 3. Fallback: Parse current URL and find link pointing to (chapter - 1) or (chapter + 1)
        const currentUrl = window.location.href;
        const chMatch = currentUrl.match(/chapter[=_/-](\d+)/i);
        if (chMatch) {
            const currentCh = parseInt(chMatch[1], 10);
            const targetCh = direction === 'prev' ? currentCh - 1 : currentCh + 1;
            if (targetCh >= 0) {
                const targetLink = document.querySelector(`a[href*="chapter=${targetCh}"], a[href*="chapter-${targetCh}"], a[href*="chapter/${targetCh}"], a[href*="ch-${targetCh}"]`);
                if (targetLink) return targetLink;
            }
        }

        return null;
    }

    function goToChapter(direction) {
        const link = findChapterLink(direction);
        if (link) {
            bannerText.innerText = direction === 'prev' ? "<< PREV CHAPTER <<" : ">> NEXT CHAPTER >>";
            banner.style.color = "#00ffea";
            if (link.href && link.href !== "#" && !link.href.startsWith("javascript:")) {
                window.location.href = link.href;
            } else {
                link.click();
            }
        } else {
            // Keyboard event fallback
            window.dispatchEvent(new KeyboardEvent('keydown', { key: direction === 'prev' ? 'ArrowLeft' : 'ArrowRight', bubbles: true }));
            if (document.getElementById("webtoon-scroll-area")) {
                bannerText.innerText = direction === 'prev' ? "<< PREV (Active on Manga Sites) <<" : ">> NEXT (Active on Manga Sites) >>";
                banner.style.color = "#fbbf24";
            } else {
                bannerText.innerText = direction === 'prev' ? "<< PREV CHAPTER <<" : ">> NEXT CHAPTER >>";
                banner.style.color = "#00ffea";
            }
        }
    }

    // Invisible Smart Edge Navigation (100% unobstructed reading - zero blue dashed borders!)
    const edgePrev = document.createElement("div");
    edgePrev.className = "irfanllm-edge-zone";
    edgePrev.style.left = "0";
    edgePrev.style.justifyContent = "flex-start";

    const edgePillPrev = document.createElement("div");
    edgePillPrev.className = "irfanllm-edge-pill";
    edgePillPrev.style.marginLeft = "6px";
    edgePillPrev.style.transform = "translateX(-15px)";
    edgePillPrev.innerText = "‹ PREV";
    edgePillPrev.title = "Tap or Hover hand to go to Previous Chapter";
    edgePrev.appendChild(edgePillPrev);

    edgePrev.onclick = (e) => {
        e.stopPropagation();
        edgePillPrev.classList.add("hovered");
        setTimeout(() => edgePillPrev.classList.remove("hovered"), 250);
        goToChapter('prev');
    };
    edgePrev.onmouseenter = () => {
        edgePillPrev.style.opacity = "1";
        edgePillPrev.style.transform = "translateX(0)";
    };
    edgePrev.onmouseleave = () => {
        if (!btnPrevHoverStart) {
            edgePillPrev.style.opacity = "0";
            edgePillPrev.style.transform = "translateX(-15px)";
        }
    };
    container.appendChild(edgePrev);

    const edgeNext = document.createElement("div");
    edgeNext.className = "irfanllm-edge-zone";
    edgeNext.style.right = "0";
    edgeNext.style.justifyContent = "flex-end";

    const edgePillNext = document.createElement("div");
    edgePillNext.className = "irfanllm-edge-pill";
    edgePillNext.style.marginRight = "6px";
    edgePillNext.style.transform = "translateX(15px)";
    edgePillNext.innerText = "NEXT ›";
    edgePillNext.title = "Tap or Hover hand to go to Next Chapter";
    edgeNext.appendChild(edgePillNext);

    edgeNext.onclick = (e) => {
        e.stopPropagation();
        edgePillNext.classList.add("hovered");
        setTimeout(() => edgePillNext.classList.remove("hovered"), 250);
        goToChapter('next');
    };
    edgeNext.onmouseenter = () => {
        edgePillNext.style.opacity = "1";
        edgePillNext.style.transform = "translateX(0)";
    };
    edgeNext.onmouseleave = () => {
        if (!btnNextHoverStart) {
            edgePillNext.style.opacity = "0";
            edgePillNext.style.transform = "translateX(15px)";
        }
    };
    container.appendChild(edgeNext);

    // Compatibility proxies so MediaPipe hover tracking smoothly triggers edge pill animations
    const btnPrev = {
        style: {
            set background(bg) {
                if (bg && (bg.includes("255") || bg.includes("0.7"))) {
                    edgePillPrev.classList.add("hovered");
                } else {
                    edgePillPrev.classList.remove("hovered");
                    edgePillPrev.style.opacity = "0";
                    edgePillPrev.style.transform = "translateX(-15px)";
                }
            }
        }
    };

    const btnNext = {
        style: {
            set background(bg) {
                if (bg && (bg.includes("255") || bg.includes("0.7"))) {
                    edgePillNext.classList.add("hovered");
                } else {
                    edgePillNext.classList.remove("hovered");
                    edgePillNext.style.opacity = "0";
                    edgePillNext.style.transform = "translateX(15px)";
                }
            }
        }
    };

    document.body.appendChild(container);

    // Dynamic Script Loader
    function loadScript(src) {
        return new Promise((resolve, reject) => {
            if ((src.includes("hands") || src.includes("mediapipe")) && (typeof Hands !== "undefined" || typeof window.Hands !== "undefined")) {
                return resolve();
            }
            if (document.querySelector(`script[src="${src}"]`)) return resolve();
            const s = document.createElement("script");
            s.src = src;
            s.onload = resolve;
            s.onerror = () => reject(new Error("Failed to load: " + src));
            document.head.appendChild(s);
        });
    }

    // Decision Tree Evaluator
    function evaluateTree(nodes, features) {
        let nodeIdx = 0;
        while (true) {
            const [feat, thresh, left, right, val] = nodes[nodeIdx];
            if (feat === -2) {
                const total = val[0] + val[1];
                return [val[0] / total, val[1] / total];
            }
            if (features[feat] <= thresh) {
                nodeIdx = left;
            } else {
                nodeIdx = right;
            }
        }
    }

    function predictPosture(features) {
        let pDown = 0.0, pUp = 0.0;
        const trees = POSTURE_MODEL.trees;
        for (let i = 0; i < trees.length; i++) {
            const res = evaluateTree(trees[i], features);
            pDown += res[0];
            pUp += res[1];
        }
        return [pDown / trees.length, pUp / trees.length];
    }

    function extractFeatures(lm) {
        const wrist = lm[0];
        const palmScale = Math.hypot(lm[9].x - wrist.x, lm[9].y - wrist.y) || 1.0;
        const feats = [];
        for (let i = 0; i < lm.length; i++) {
            feats.push((lm[i].x - wrist.x) / palmScale);
            feats.push((lm[i].y - wrist.y) / palmScale);
            feats.push((lm[i].z - wrist.z) / palmScale);
        }
        const dxMid = lm[9].x - wrist.x;
        const dyMid = lm[9].y - wrist.y;
        const angleHand = Math.atan2(dyMid, dxMid);

        const dThumb = Math.hypot(lm[4].x - wrist.x, lm[4].y - wrist.y) / palmScale;
        const dIndex = Math.hypot(lm[8].x - wrist.x, lm[8].y - wrist.y) / palmScale;
        const dMid   = Math.hypot(lm[12].x - wrist.x, lm[12].y - wrist.y) / palmScale;
        const dRing  = Math.hypot(lm[16].x - wrist.x, lm[16].y - wrist.y) / palmScale;
        const dPinky = Math.hypot(lm[20].x - wrist.x, lm[20].y - wrist.y) / palmScale;

        feats.push(angleHand, dThumb, dIndex, dMid, dRing, dPinky, wrist.x, wrist.y);
        return { feats, dMid };
    }

    function performScroll(dy) {
        const demoArea = document.getElementById("webtoon-scroll-area");
        if (demoArea) {
            demoArea.scrollTop += dy;
            if (Math.abs(currentVelocity) > 1.0) {
                demoArea.style.borderColor = currentVelocity > 0 ? "#00ff66" : "#00e5ff";
                demoArea.style.boxShadow = currentVelocity > 0 ? "0 0 12px rgba(0,255,102,0.3)" : "0 0 12px rgba(0,229,255,0.3)";
            } else {
                demoArea.style.borderColor = "";
                demoArea.style.boxShadow = "";
            }
            return;
        }

        const before = window.scrollY || window.pageYOffset || (document.documentElement ? document.documentElement.scrollTop : 0);
        window.scrollBy(0, dy);
        const after = window.scrollY || window.pageYOffset || (document.documentElement ? document.documentElement.scrollTop : 0);

        // Fallback for reader areas that use custom scrollable containers
        if (before === after && Math.abs(dy) > 0.5) {
            const scroller = document.scrollingElement || document.querySelector("#readerarea, .reader-area, .reading-content, .chapter-content, #chapter-container, main");
            if (scroller && scroller.scrollHeight > scroller.clientHeight) {
                scroller.scrollTop += dy;
            }
        }
    }

    // High-frequency kinetic physics loop (runs on display refresh rate: 60Hz / 90Hz / 120Hz)
    function physicsLoop(now) {
        if (!window.__IRFANLLM_ACTIVE__) return;

        const dt = Math.min(Math.max((now - lastPhysicsTime) / 16.67, 0.2), 2.5);
        lastPhysicsTime = now;

        if (targetVelocity !== 0) {
            // Smoothly ease into target cruise speed (smartphone touch drag)
            currentVelocity += (targetVelocity - currentVelocity) * ACCELERATION * dt;
        } else {
            // Exponential kinetic friction coasting (smartphone swipe inertia)
            currentVelocity *= Math.pow(FRICTION, dt);
            if (Math.abs(currentVelocity) < 0.18) {
                currentVelocity = 0;
            }
        }

        if (Math.abs(currentVelocity) > 0.08) {
            performScroll(currentVelocity * dt);
        }

        physicsAnimId = requestAnimationFrame(physicsLoop);
    }

    // Resilient Camera Acquisition with multi-tier fallback
    async function acquireCameraStream() {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
            throw new Error("getUserMedia is not supported on this browser context.");
        }

        // Check if Permissions-Policy is blocking camera on this document
        if (document.permissionsPolicy && typeof document.permissionsPolicy.allowsFeature === 'function') {
            if (!document.permissionsPolicy.allowsFeature('camera')) {
                const err = new Error("POLICY_BLOCKED");
                err.name = "PermissionsPolicyViolation";
                throw err;
            }
        }

        const constraintsList = [
            { video: { facingMode: { ideal: "user" }, width: { ideal: 640 }, height: { ideal: 480 } } },
            { video: { facingMode: "user" } },
            { video: true }
        ];

        let lastErr = null;
        for (const c of constraintsList) {
            try {
                const s = await navigator.mediaDevices.getUserMedia(c);
                if (s) return s;
            } catch (e) {
                lastErr = e;
                console.warn("[IrfanLLM] Constraint failed:", c, e);
            }
        }
        throw lastErr || new Error("Failed to acquire camera stream");
    }

    async function init() {
        try {
            bannerText.innerText = "Loading MediaPipe AI...";
            banner.style.color = "#00e5ff";
            banner.style.borderColor = "#00e5ff";
            
            if (typeof Hands === "undefined" && typeof window.Hands === "undefined") {
                await loadScript("https://cdn.jsdelivr.net/npm/@mediapipe/hands/hands.js");
            }

            handsInstance = new Hands({
                locateFile: (file) => `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`
            });

            handsInstance.setOptions({
                maxNumHands: 1,
                modelComplexity: 0,
                minDetectionConfidence: 0.35,
                minTrackingConfidence: 0.35
            });

            handsInstance.onResults((results) => {
                const now = Date.now();
                if (!results.multiHandLandmarks || results.multiHandLandmarks.length === 0) {
                    targetVelocity = 0;
                    lastWristY = null;
                    lastWristTime = 0;
                    if (Math.abs(currentVelocity) > 0.8) {
                        bannerText.innerText = currentVelocity > 0 ? "vv Gliding... vv" : "^^ Gliding... ^^";
                        banner.style.color = "#38bdf8";
                    } else {
                        bannerText.innerText = "IrfanLLM: Ready (Waiting for Hand)";
                        banner.style.color = "#aaa";
                    }
                    btnPrev.style.background = "rgba(0,100,200,0.25)";
                    btnNext.style.background = "rgba(0,100,200,0.25)";
                    btnPrevHoverStart = null;
                    btnNextHoverStart = null;
                    return;
                }

                const lm = results.multiHandLandmarks[0];
                const indexTip = lm[8];
                const screenX = (1.0 - indexTip.x) * window.innerWidth;
                const screenY = indexTip.y * window.innerHeight;

                // 1. Air Button Checks (Prev / Next Chapter)
                const hoverBoundary = Math.max(90, window.innerWidth * 0.22);
                const inLeft = (screenX <= hoverBoundary && screenY >= window.innerHeight * 0.20 && screenY <= window.innerHeight * 0.70);
                const inRight = (screenX >= window.innerWidth - hoverBoundary && screenY >= window.innerHeight * 0.20 && screenY <= window.innerHeight * 0.70);

                if (inLeft) {
                    targetVelocity = 0;
                    btnPrev.style.background = "rgba(0,255,200,0.7)";
                    if (!btnPrevHoverStart) btnPrevHoverStart = now;
                    else if (now - btnPrevHoverStart > 220 && now > cooldownUntil) {
                        cooldownUntil = now + COOLDOWN_BUTTON;
                        goToChapter('prev');
                    }
                    return;
                } else {
                    btnPrevHoverStart = null;
                    btnPrev.style.background = "rgba(0,100,200,0.3)";
                }

                if (inRight) {
                    targetVelocity = 0;
                    btnNext.style.background = "rgba(0,255,200,0.7)";
                    if (!btnNextHoverStart) btnNextHoverStart = now;
                    else if (now - btnNextHoverStart > 220 && now > cooldownUntil) {
                        cooldownUntil = now + COOLDOWN_BUTTON;
                        goToChapter('next');
                    }
                    return;
                } else {
                    btnNextHoverStart = null;
                    btnNext.style.background = "rgba(0,100,200,0.3)";
                }

                // 2. Physical Hand Motion Swipe / Flick Detection
                const wrist = lm[0];
                if (lastWristY !== null && lastWristTime > 0) {
                    const elapsed = (now - lastWristTime) / 1000;
                    if (elapsed > 0.02 && elapsed < 0.25) {
                        const vY = (wrist.y - lastWristY) / elapsed; // normalized camera speed
                        if (vY > 1.25) {
                            // Swift downward hand motion -> boost scroll down
                            currentVelocity = Math.min(Math.max(currentVelocity, 0) + (FLICK_BOOST * speedMultiplier), 32);
                            bannerText.innerText = "⚡ Swipe Flick Down";
                            banner.style.color = "#00ffea";
                        } else if (vY < -1.25) {
                            // Swift upward hand motion -> boost scroll up
                            currentVelocity = Math.max(Math.min(currentVelocity, 0) - (FLICK_BOOST * speedMultiplier), -32);
                            bannerText.innerText = "⚡ Swipe Flick Up";
                            banner.style.color = "#00ffea";
                        }
                    }
                }
                lastWristY = wrist.y;
                lastWristTime = now;

                // 3. Middle Zone AI Posture Classification
                const { feats, dMid } = extractFeatures(lm);
                if (dMid > 1.35) {
                    targetVelocity = 0;
                    if (Math.abs(currentVelocity) > 0.8) {
                        bannerText.innerText = currentVelocity > 0 ? "vv Gliding... vv" : "^^ Gliding... ^^";
                        banner.style.color = "#38bdf8";
                    } else {
                        bannerText.innerText = "Relaxed / Open Hand (Idle)";
                        banner.style.color = "#ffea00";
                    }
                    return;
                }

                const [pDown, pUp] = predictPosture(feats);

                if (pDown >= CONF_THRESHOLD) {
                    targetVelocity = BASE_CRUISE_SPEED * speedMultiplier;
                    bannerText.innerText = `vv Fluid Glide Down (${Math.round(pDown*100)}%) vv`;
                    banner.style.color = "#00ff66";
                } else if (pUp >= CONF_THRESHOLD) {
                    targetVelocity = -BASE_CRUISE_SPEED * speedMultiplier;
                    bannerText.innerText = `^^ Fluid Glide Up (${Math.round(pUp*100)}%) ^^`;
                    banner.style.color = "#00ff66";
                } else {
                    targetVelocity = 0;
                    if (Math.abs(currentVelocity) > 0.8) {
                        bannerText.innerText = currentVelocity > 0 ? "vv Gliding... vv" : "^^ Gliding... ^^";
                        banner.style.color = "#38bdf8";
                    } else {
                        bannerText.innerText = "Uncertain Posture (Idle)";
                        banner.style.color = "#aaa";
                    }
                }
            });

            bannerText.innerText = "Requesting Front Camera...";
            banner.style.color = "#00e5ff";

            activeStream = await acquireCameraStream();
            video.srcObject = activeStream;

            await new Promise((resolve) => {
                video.onloadedmetadata = () => {
                    video.play().then(resolve).catch(resolve);
                };
            });

            bannerText.innerText = "IrfanLLM Active! Hold gesture to scroll.";
            banner.style.color = "#00ff66";
            banner.style.borderColor = "#00ff66";
            try {
                sessionStorage.setItem("__IRFANLLM_ACTIVE__", "true");
            } catch (e) {}

            // Update on-page trigger button to Stop state
            const pageBtn = document.getElementById("btn-camera");
            if (pageBtn) {
                pageBtn.innerText = "⏹️ Stop Camera Demo";
                pageBtn.style.background = "#dc2626";
                pageBtn.disabled = false;
            }

            // High-performance requestAnimationFrame loop with concurrency protection
            async function frameLoop() {
                if (!video.paused && !video.ended && video.readyState >= 2) {
                    if (!isProcessing && handsInstance) {
                        isProcessing = true;
                        try {
                            await handsInstance.send({ image: video });
                        } catch (err) {
                            console.warn("[IrfanLLM] Frame drop:", err);
                        } finally {
                            isProcessing = false;
                        }
                    }
                }
                if (window.__IRFANLLM_ACTIVE__) {
                    animFrameId = requestAnimationFrame(frameLoop);
                }
            }
            animFrameId = requestAnimationFrame(frameLoop);
            lastPhysicsTime = performance.now();
            physicsAnimId = requestAnimationFrame(physicsLoop);

        } catch (err) {
            console.error("[IrfanLLM] Initialization Error:", err);
            const pageBtn = document.getElementById("btn-camera");
            if (pageBtn) {
                pageBtn.innerText = "Activate Front Camera Demo";
                pageBtn.style.background = "";
                pageBtn.disabled = false;
            }

            const isPolicyBlocked = (err.name === "PermissionsPolicyViolation" || err.message === "POLICY_BLOCKED" || (err.message && err.message.toLowerCase().includes("permissions policy")));

            banner.style.cursor = "pointer";
            banner.style.background = "rgba(180,0,0,0.92)";
            banner.style.borderColor = "#ff4444";
            banner.style.color = "#ffffff";

            if (isPolicyBlocked) {
                bannerText.innerText = "Domain Header Blocked Camera (Tap for Guide)";
                const showPolicyHelp = () => {
                    alert(
                        "CAMERA BLOCKED BY CLOUDFLARE / GITHUB PAGES HEADER:\n\n" +
                        "GitHub Pages enforces 'Permissions-Policy: camera=()' on all custom domains by default.\n\n" +
                        "2 WAYS TO RESOLVE:\n" +
                        "1. DEMONICSCANS BOOKMARKLET (Immediate):\n" +
                        "Use the 1-line bookmarklet on demonicscans.org (or any manga site). DemonicScans does NOT have this header, so the camera opens immediately!\n\n" +
                        "2. CLOUDFLARE DASHBOARD FIX (2 Minutes):\n" +
                        "Open dash.cloudflare.com -> Select irfanfahmi.com -> Rules -> Transform Rules -> Modify Response Header.\n" +
                        "Rule: URI Path starts with '/manga' -> Action: Remove response header 'Permissions-Policy' (or set camera=*)."
                    );
                };
                banner.onclick = showPolicyHelp;
            } else if (err.name === "NotAllowedError" || (err.message && err.message.includes("Permission denied"))) {
                bannerText.innerText = "Camera Permission Denied (Tap for Help)";
                const showPermHelp = () => {
                    alert(
                        "CAMERA PERMISSION DENIED:\n\n" +
                        "1. Tap the Tune / Lock icon in your browser's address bar.\n" +
                        "2. Go to 'Site settings' -> 'Permissions' -> 'Camera'.\n" +
                        "3. Change to 'Allow' and refresh the page."
                    );
                };
                banner.onclick = showPermHelp;
            } else {
                bannerText.innerText = "Camera Error: " + (err.name || err.message);
                banner.onclick = () => alert("Camera Error:\n" + (err.stack || err.message || err));
            }
        }
    }

    init();
})();
